// 出题端参考树导出入口；依赖 BurrTools 的 GPL-2.0-or-later 库。
// 求解实现固定版本见 ../参考答案.md。本文件不实现搜索算法。
#include "lib/puzzle.h"
#include "lib/problem.h"
#include "lib/assembly.h"
#include "lib/disassembler_0.h"
#include "lib/disassembly.h"
#include "lib/solution.h"
#include "lib/voxel.h"
#include "tools/xml.h"
#include "tools/gzstream.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
int main(int argc,char** argv){
 if(argc<3){std::cerr<<"usage: export_reference input.xmpuzzle output.xml [solution_index]\n";return 2;}
 auto in=openGzFile(argv[1]);xmlParser_c parser(*in);puzzle_c p(parser);
 for(unsigned i=0;i<p.getNumberOfShapes();i++)p.getShape(i)->initHotspot();
 auto pr=p.getProblem(0);disassembler_0_c d(*pr);std::ofstream out(argv[2]);xmlWriter_c xml(out);xml.newTag("references");
 for(unsigned i=(argc>3?std::atoi(argv[3]):0);i<pr->getNumberOfSavedSolutions()&&(argc<=3||i==unsigned(std::atoi(argv[3])));i++){
 auto a=pr->getSavedSolution(i)->getAssembly(); auto da=d.disassemble(a);if(!da)continue;
 xml.newTag("reference");a->save(xml);da->save(xml);xml.endTag("reference");std::cerr<<i<<" level "<<da->getMoves()<<" total "<<da->sumMoves()<<"\n";
 }xml.endTag("references");}

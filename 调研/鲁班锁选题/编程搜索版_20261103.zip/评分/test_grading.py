"""运行：python -m unittest discover -s . -p test_grading.py"""
import copy
import importlib.util
import unittest
import tempfile
from unittest.mock import patch
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("grade_burr", HERE / "grade.py")
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)
check = grader.checker


def puzzle(points):
    return {"id": "test", "pieces": [
        {"id": chr(65+i), "position": list(p), "voxels": [[0, 0, 0]]}
        for i, p in enumerate(points)]}


def answer(moves, removed=None, remaining=None):
    return {"puzzle": "test", "plan": {
        "moves": moves, "removed": removed, "remaining": remaining}}


class JudgeTests(unittest.TestCase):
    def test_saved_reference_solutions(self):
        records = check.load(HERE / "references.json")["records"]
        self.assertEqual(len(records), 6)
        for record in records:
            key = record["id"]
            with self.subTest(puzzle=key):
                result = check.validate(
                    check.load(grader.PUBLIC / "题目" / f"{key}.json"),
                    check.load(HERE / "标准解答" / f"第{key}题.json"))
                self.assertEqual(result["moves"], record["reference_moves"])
                self.assertEqual(result["separations"], record["piece_count"]-1)

    def test_swept_collision_even_when_endpoint_clear(self):
        p = puzzle([(0, 0, 0), (2, 0, 0)])
        a = answer([{"pieces": ["A"], "delta": [4, 0, 0]},
                    {"pieces": ["A"], "out": [0, 1, 0]}])
        with self.assertRaises(check.Invalid):
            check.validate(p, a)

    def test_out_checks_all_future_distance(self):
        p = puzzle([(0, 0, 0), (100000, 0, 0)])
        with self.assertRaises(check.Invalid):
            check.validate(p, answer([{"pieces": ["A"], "out": [1, 0, 0]}]))

    def test_touching_faces_and_arbitrary_valid_path(self):
        p = puzzle([(0, 0, 0), (1, 0, 0)])
        result = check.validate(p, answer([{"pieces": ["A"], "out": [0, 1, 0]}]))
        self.assertEqual(result["moves"], 1)

    def test_continuous_commands_merge_including_out(self):
        p = puzzle([(0, 0, 0), (0, 2, 0)])
        a = answer([{"pieces": ["A"], "delta": [1, 0, 0]},
                    {"pieces": ["A"], "delta": [3, 0, 0]},
                    {"pieces": ["A"], "out": [1, 0, 0]}])
        self.assertEqual(check.validate(p, a)["moves"], 1)

    def test_subassembly_branches_must_both_finish(self):
        p = puzzle([(0, 0, 0), (1, 0, 0), (2, 0, 0)])
        a = answer([{"pieces": ["A", "B"], "out": [0, 1, 0]}])
        with self.assertRaises(check.Invalid):
            check.validate(p, a)
        a["plan"]["removed"] = {
            "moves": [{"pieces": ["A"], "out": [-1, 0, 0]}],
            "removed": None, "remaining": None}
        self.assertEqual(check.validate(p, a)["moves"], 2)

    def test_foreign_piece_rotation_and_zero_displacement_rejected(self):
        p = puzzle([(0, 0, 0), (1, 0, 0)])
        for move in [{"pieces": ["X"], "out": [0, 1, 0]},
                     {"pieces": ["A"], "delta": [0, 0, 0]},
                     {"pieces": ["A"], "delta": [1, 1, 0]},
                     {"pieces": ["A", "A"], "out": [-1, 0, 0]},
                     {"pieces": ["A", "B"], "out": [0, 1, 0]}]:
            with self.subTest(move=move), self.assertRaises(check.Invalid):
                check.validate(p, answer([move]))

    def test_new_shorter_solution_rebases_every_model(self):
        original_load = check.load
        record = original_load(HERE / "references.json")
        record["records"][0]["reference_moves"] += 10
        def load(path):
            return copy.deepcopy(record) if Path(path) == HERE / "references.json" else original_load(path)
        with tempfile.TemporaryDirectory() as folder:
            roots = [Path(folder) / name for name in ("shorter", "longer")]
            for root in roots:
                (root / "答案").mkdir(parents=True)
                for source in (HERE / "标准解答").glob("*.json"):
                    (root / "答案" / source.name).write_bytes(source.read_bytes())
            path = roots[1] / "答案" / "第01题.json"
            longer = original_load(path)
            first = copy.deepcopy(longer["plan"]["moves"][0])
            undo = copy.deepcopy(first)
            undo["delta"] = [-x for x in undo["delta"]]
            longer["plan"]["moves"] = [first, undo] + longer["plan"]["moves"]
            import json
            path.write_text(json.dumps(longer), encoding="utf-8")
            with patch.object(check, "load", side_effect=load):
                result = grader.grade(roots)
            one, two = result["results"]
            self.assertEqual(one["total"], 100)
            self.assertGreater(one["items"][0]["score"], two["items"][0]["score"])
            self.assertEqual(one["items"][0]["baseline_moves"], two["items"][0]["baseline_moves"])
            self.assertLess(result["baselines"]["01"], record["records"][0]["reference_moves"])

    def test_missing_answers_do_not_read_reference_directory(self):
        result = grader.grade([HERE])
        self.assertEqual(result["results"][0]["total"], 0)
        self.assertTrue(all(not item["valid"] for item in result["results"][0]["items"]))


if __name__ == "__main__":
    unittest.main()

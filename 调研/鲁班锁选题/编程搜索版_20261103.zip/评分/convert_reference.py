"""把 BurrTools 的分离树转换为本题答案；只供出题端使用。"""
import argparse
import json
import xml.etree.ElementTree as ET
from pathlib import Path


def convert(node, labels):
    ids = list(map(int, node.findtext("pieces").split()))
    states = []
    for state in node.findall("state"):
        columns = [list(map(int, state.findtext(axis).split())) for axis in ("dx", "dy", "dz")]
        states.append(list(zip(*columns)))
    moves = []
    for before, after in zip(states, states[1:]):
        differences = [tuple(b-a for a, b in zip(p, q)) for p, q in zip(before, after)]
        removed = [i for i, delta in enumerate(differences) if any(abs(x) > 10000 for x in delta)]
        if removed:
            values = {differences[i] for i in removed}
            if len(values) != 1:
                raise ValueError("无法识别参考树的移出标记")
            delta = values.pop()
            axis = next(i for i, x in enumerate(delta) if abs(x) > 10000)
            ray = [0, 0, 0]
            ray[axis] = 1 if delta[axis] > 0 else -1
            moves.append({"pieces": [labels[ids[i]] for i in removed], "out": ray})
            continue
        # 去掉参考状态可能带有的整体平移，只保留零件之间的相对运动。
        base = differences[0]
        relative = [tuple(x-y for x, y in zip(delta, base)) for delta in differences]
        values = set(relative) - {(0, 0, 0)}
        if len(values) != 1:
            raise ValueError("参考状态之间不是一次轴向组移动")
        delta = values.pop()
        if sum(x != 0 for x in delta) != 1:
            raise ValueError("参考状态之间含有多轴移动")
        moves.append({"pieces": [labels[ids[i]] for i, v in enumerate(relative) if any(v)],
                      "delta": list(delta)})
    result = {"moves": moves, "removed": None, "remaining": None}
    for child in node.findall("separation"):
        branch = "removed" if child.get("type") == "removed" else "remaining"
        result[branch] = convert(child, labels)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("puzzle", type=Path)
    parser.add_argument("reference_xml", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    puzzle = json.loads(args.puzzle.read_text(encoding="utf-8-sig"))
    root = ET.parse(args.reference_xml).getroot()
    node = root if root.tag == "separation" else root.find(".//separation")
    if node is None:
        raise ValueError("文件不含分离树")
    answer = {"puzzle": puzzle["id"], "plan": convert(node, [p["id"] for p in puzzle["pieces"]])}
    args.output.write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
